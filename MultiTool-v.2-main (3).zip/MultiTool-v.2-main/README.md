# MultiTool-v.2

            ░▒▓████████▓▒░  ░▒▓██████▓▒░   ░▒▓██████▓▒░  ░▒▓█▓▒░              
               ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░              
               ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░              
               ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░              
               ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░              
               ░▒▓█▓▒░      ░▒▓██████▓▒░   ░▒▓██████▓▒░  ░▒▓████████▓▒░
Voici un tool vraiment très basique, Il n'est pas dans le but de vendre des choses ou autre mais dans le but de s'entraider à faire un tool très utile.

ATTENTION : Je ne suis pas un expert en info tout ça je me proclame rien du tout. J'aimerai juste qu'on s'entraide à faire le même objectif, Avoir son propre tool personnalisé.

On accepte tout types de niveau, tout le monde mais dans la bienveillance, l'humilité totale.

Rejoingnez notre serveur discord !
